package org.sitenv.spring.query;

import java.io.Serializable;

/**
 * Created by Prabhushankar.Byrapp on 8/23/2015.
 */
public class SearchCriteria implements Serializable {

}
